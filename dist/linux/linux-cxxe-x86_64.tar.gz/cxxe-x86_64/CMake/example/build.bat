cmake --build build
pause